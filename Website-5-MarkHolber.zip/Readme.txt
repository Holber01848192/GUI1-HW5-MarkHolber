Github Link:
Website Link:


Write up:
For the HTMl, I designed it with a title and pertinent information at the top. The tile holder
with its 7 randomly generated tiles on one side, with the board on the other. Beneathe the board is 
the current score, the current word, and the final score which is submitted.

For the CSS, the background of the whole page is a light blue, with the pictures for the tile holder
and the game board being assigned here. The text size and all related information is here as well.

For the JavaScript, I have all the tiles be hidden, and only reveal the 7 that are randomly selected. 
I then match the number generated to its relevant letter equivalent, and then reveal that specific tile
in the holder. The tiles can then be dragged over to the game board, which would add to both the score
and the current word composition. When new tiles are selected, the score and the word are both reset.
When the submit button is pressed, the final score is updated, and that is the final score of the game.